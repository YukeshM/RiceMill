﻿namespace RiceMill
{
    internal class IBALInterface
    {
    }
}