﻿
using CustomIdentity;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using ViewModel;

namespace RiceMill.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> _userManager;

        private readonly SignInManager<ApplicationUser> _signInManager;

        public AccountController(UserManager<ApplicationUser> userManager,
                                SignInManager<ApplicationUser> signInManager)
        {
            this._userManager = userManager;
            this._signInManager = signInManager;
        }

        [HttpGet]
        public IActionResult Create()
        {
            return Ok();
        }

        [HttpPost("Create")]
        public async Task<IActionResult> Create(UserViewModel user)
        {
            if (ModelState.IsValid)
            {
                var userDetail = new ApplicationUser
                {
                    UserName = user.FirstName,
                    LastName = user.LastName,
                    Age = user.Age,
                    GenderId = user.GenderId,
                    PasswordHash = user.PasswordHash,
                    PhoneNumber = user.PhoneNumber,
                    Email = user.Email
                };

                var result = await _userManager.CreateAsync(userDetail, user.PasswordHash);

                if (result.Succeeded)
                {
                    await _signInManager.SignInAsync(userDetail, isPersistent: false);
                    return Ok();
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }

            }
            return BadRequest(user);

        }


        [HttpPost("Login")]
        public async Task<IActionResult> Login(LoginViewModel login)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByEmailAsync(login.Email);
                var result = await _signInManager.PasswordSignInAsync(user.UserName, login.Password, false, false);

                if (result.Succeeded)
                {
                    //var secretkey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("superSecretKey@345"));
                    //var signingCredentials = new SigningCredentials(secretkey);

                    //var userId = await _userManager.FindByIdAsync(user.Id);
                    //var userId = Guid.NewGuid(user.Id)
                    ApplicationUser userId = new ApplicationUser()
                    {
                        Id = user.Id
                    };

                    var role = await _userManager.GetRolesAsync(userId);

                    //ApplicationRole newRole = new ApplicationRole()
                    //{
                    //    Name = _userManager.GetRolesAsync(userId).ToString()
                    //};
                    //var Id = userId.ToString();
                    var claims = new List<Claim>()
                    {
                        new Claim(ClaimTypes.Name, user.UserName),
                        new Claim(ClaimTypes.Email, user.Email),
                        new Claim("Id", userId.Id.ToString()),
                        //JwtRegisteredClaimNames.Sub
                        new Claim(ClaimTypes.Role, role[0].ToString())
                    };


                    //var tokenoptions = new JwtSecurityToken(issuer: "https://localhost:44329",
                    //                                        audience: "https://localhost:4200",
                    //                                        claims: claims,
                    //                                        expires: DateTime.Now.AddMinutes(25),
                    //                                        signingCredentials: signingCredentials
                    //                                        );

                    var tokenDescriptor = new SecurityTokenDescriptor()
                    {
                        Subject = new ClaimsIdentity(claims),
                        Issuer = "https://localhost:44329",
                        Audience = "https://localhost:4200",
                        Expires = DateTime.Now.AddMinutes(25),
                        SigningCredentials = new SigningCredentials(
                 new SymmetricSecurityKey(Encoding.UTF8.GetBytes("superSecretKey@345")), SecurityAlgorithms.HmacSha256Signature)
                    };

                    var tokenHandler = new JwtSecurityTokenHandler();

                    var tokenstring = tokenHandler.CreateToken(tokenDescriptor);
                    return Ok(new
                    {
                        token = tokenHandler.WriteToken(tokenstring)
                    });
                }
                return BadRequest("Error occured");
            }
            return BadRequest("enter valid creditentials");
        }

    }
}




