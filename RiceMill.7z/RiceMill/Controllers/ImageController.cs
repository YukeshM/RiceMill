﻿using IBAL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using RiceMill.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ViewModel;

namespace RiceMill.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ImageController : ControllerBase
    {
        private readonly IImageBAL _imageBAL;


        private readonly IOptions<PathModel> _folderPath;


        public ImageController(IImageBAL imageBAL, IOptions<PathModel> folderPath)
        {
            _imageBAL = imageBAL;
            _folderPath = folderPath;

        }

        [Authorize(Roles = "User")]
        [HttpGet]
        public IActionResult GetImageByProductId(int id)
        {
            if (id != 0)
            {
                ImageViewModel image = _imageBAL.Get(id);


                FileStream newImage = System.IO.File.OpenRead(_folderPath.Value.FolderPath + "\\" + image.FileName);
                return File(newImage, "image/jpeg");

            }
            return BadRequest("image id cannot be 0");
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult Create(IFormFileCollection file)
        {
            var uploadFile = file["file"];

            ImageViewModel newImage = new();

            var folderName = _folderPath.Value.FolderPath;

            var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), folderName);

            if (!Directory.Exists(uploadDirectory))
            {
                Directory.CreateDirectory(uploadDirectory);
            }

            if (uploadFile.Length > 0)
            {
                newImage.FileName = DateTime.UtcNow.ToString("yyyyMMddHHmmssfff");
                newImage.OriginalFileName = uploadFile.FileName;

                var imagePath = Path.Combine(uploadDirectory, newImage.FileName);
                using (var stream = new FileStream(imagePath, FileMode.Create))
                {
                    uploadFile.CopyTo(stream);
                }
            }

            _imageBAL.Create(newImage);
            return Ok();
        }

        [Authorize(Roles = "User")]
        [HttpGet]
        public IActionResult GetImages()
        {
            try
            {
                IEnumerable<ImageViewModel> images = _imageBAL.GetImages().ToList();

                return Ok(images);
            }
            catch (Exception e)
            {

                throw new Exception("Error: " + e);
            }
        }

        [Authorize(Roles = "User")]
        [HttpGet]
        public IActionResult GetImageById(int id)
        {
           
                ImageViewModel images = _imageBAL.GetImageById(id);

                FileStream newImage = System.IO.File.OpenRead(_folderPath.Value.FolderPath + "\\" + images.FileName);
                return File(newImage, "image/jpeg");

            
            //return BadRequest("Id cannot be zero");
        }

        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult GetImagesCarousel()
        {
            try
            {
                IEnumerable<ImageViewModel> images = _imageBAL.GetCarousel().ToList();

                return Ok(images);
            }
            catch (Exception e)
            {

                throw new Exception("Error: " + e);
            }
        }
    }
}
