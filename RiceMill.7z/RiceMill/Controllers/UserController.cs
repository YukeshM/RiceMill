﻿using IBAL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using ViewModel;

namespace RiceMill.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserBAL _userBAL;

        public UserController(IUserBAL userBAL)
        {
            _userBAL = userBAL;
        }

        [HttpGet, Authorize(Roles = "User")]
        public IActionResult GetGender()
        {
            List<GenderViewModel> gender = _userBAL.GetGender().ToList();
            return Ok(gender);
        }
    }
}
