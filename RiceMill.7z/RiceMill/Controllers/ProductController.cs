﻿using IBAL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using RiceMill.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ViewModel;

namespace RiceMill.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductController : ControllerBase
    {

        private readonly IProductBAL _productBAL;

        private readonly IOptions<PathModel> _uploadImagePath;


        public ProductController(IProductBAL productBAL, IOptions<PathModel> uploadImagePath)
        {
            _productBAL = productBAL;
            _uploadImagePath = uploadImagePath;

        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult Create(IFormCollection form, IFormFileCollection file)
        {
            //to get the id of the admin
            var id = User.Claims.FirstOrDefault(x => x.Type.ToString().Equals("Id", StringComparison.InvariantCultureIgnoreCase));

            CreateProductViewModel productViewModel = JsonConvert.DeserializeObject<CreateProductViewModel>(form["product"][0].ToString());

            var uploadFile = file["file"];

            var folderName = _uploadImagePath.Value.FolderPath;

            var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), folderName);

            if (!Directory.Exists(uploadDirectory))
            {
                Directory.CreateDirectory(uploadDirectory);
            }

            if (uploadFile.Length > 0)
            {
                productViewModel.FileName = DateTime.UtcNow.ToString("yyyyMMddHHmmssfff");
                productViewModel.OriginalFileName = uploadFile.FileName;

                var imagePath = Path.Combine(uploadDirectory, productViewModel.FileName);
                using (var stream = new FileStream(imagePath, FileMode.Create))
                {
                    uploadFile.CopyTo(stream);
                }
            }

            //id of the admin is converted into guid format
            productViewModel.CreatedBy = Guid.Parse(id.Value);
            productViewModel.CreatedOn = DateTime.UtcNow;

            _productBAL.Create(productViewModel);

            return Ok();
        }


        [HttpGet]
        public IActionResult GetProductList(string? word, int? pageIndex = 0, int? pageSize = 0)
        {
            if (pageSize == 0)
            {
                IEnumerable<GetProductViewModel> productList = _productBAL.Get(word, pageIndex, pageSize + 5).ToList();
                return Ok(productList);
            }
            else
            {
                IEnumerable<GetProductViewModel> newProductList = _productBAL.Get(word, pageIndex, pageSize).ToList();
                return Ok(newProductList);

            }
        }

        [HttpPost]
        public IActionResult Update(CreateProductViewModel model)
        {
            _productBAL.Update(model);
            return Ok();
        }


        [HttpGet]
        public IActionResult Delete(int id)
        {
            _productBAL.Delete(id);
            return Ok();
        }


        [Authorize(Roles = "User")]
        [HttpGet]
        public IActionResult GetProductById(int id)
        {
            if (id != 0)
            {
                GetProductViewModel product = _productBAL.GetProductById(id);
                return Ok(product);
            }
            return BadRequest("Id cannot be 0");
        }


        [Authorize(Roles = "User")]
        [HttpPost]
        public IActionResult PlaceOrder(PlaceOrderViewModel order)
        {
            //to get the user id from the token
            var id = User.Claims.FirstOrDefault(x => x.Type.ToString().Equals("Id", StringComparison.InvariantCultureIgnoreCase));

            PlaceOrderViewModel newOrder = new PlaceOrderViewModel()
            {
                //converting user id to guid
                UserId = Guid.Parse(id.Value),
                OrderDate = DateTime.UtcNow,
                Quantity = order.Quantity,
                ProductId = order.ProductId
            };
            _productBAL.PlaceOrder(newOrder);
            return Ok();
        }

        [Authorize(Roles = "User")]
        [HttpGet]
        public IActionResult GetOrderDetails()
        {
            List<GetOrderViewModel> orderList = _productBAL.GetOrderDetails().ToList();
            return Ok(orderList);
        }
    }


}
