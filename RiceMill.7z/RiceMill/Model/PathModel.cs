﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RiceMill.Model
{
    public class PathModel
    {
        public string FolderPath
        {
            get; set;
        }
    }
}
