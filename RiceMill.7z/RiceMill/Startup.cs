using BAL;
using CustomIdentity;
using DAL;
using Entities.Entity;
using IBAL;
using IDAL;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using RiceMill.Model;
using System;
using System.Globalization;
using System.Text;

namespace RiceMill
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration
        {
            get;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddIdentity<ApplicationUser, ApplicationRole>().AddEntityFrameworkStores<IdentityDbContext>().AddDefaultTokenProviders();


            //jwt token
            services.AddAuthentication(opt =>
            {
                opt.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                opt.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                opt.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;

            }).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,

                    ValidIssuer = "https://localhost:44329",
                    ValidAudience = "https://localhost:4200",
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("superSecretKey@345"))
                };
            });


            string connection = Configuration.GetConnectionString("DefaultConnection");

            services.AddDbContext<RicemillContext>(options => options.UseSqlServer(connection));

            services.AddDbContext<IdentityDbContext>(options => options.UseSqlServer(connection));



            services.AddScoped<IImageDAL, ImageDAL>();

            services.AddScoped<IProductDAL, ProductDAL>();

            services.AddScoped<IUserDAL, UserDal>();

            services.AddScoped<IImageBAL, ImageBAL>();
            services.AddScoped<IProductBAL, ProductBAL>();
            services.AddScoped<IUserBAL, UserBAL>();

            services.Configure<PathModel>(Configuration.GetSection("UploadPath"));

            //service for localization and its path
            services.AddLocalization(options => options.ResourcesPath = "");

            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "RiceMill", Version = "v1" });


                // Include 'SecurityScheme' to use JWT Authentication
                var jwtSecurityScheme = new OpenApiSecurityScheme
                {
                    Scheme = "bearer",
                    BearerFormat = "JWT",
                    Name = "JWT Authentication",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.Http,
                    Description = "Put **_ONLY_** your JWT Bearer token on textbox below!",

                    Reference = new OpenApiReference
                    {
                        Id = JwtBearerDefaults.AuthenticationScheme,
                        Type = ReferenceType.SecurityScheme
                    }
                };



                c.AddSecurityDefinition(jwtSecurityScheme.Reference.Id, jwtSecurityScheme);



                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                {
                        jwtSecurityScheme, Array.Empty<string>() }
                });
            });

            //cors
            services.AddCors(options =>
            {
                options.AddDefaultPolicy(builder =>
                {
                    builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
                });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "RiceMill v1"));
            }

            app.UseHttpsRedirection();

            #region setting supported languages
            //supported languages
            var supportedCultures = new[]
            {
                new CultureInfo("en-UK"),
                new CultureInfo("ta-IN")
            };

            app.UseRequestLocalization(new RequestLocalizationOptions
            {
                    DefaultRequestCulture = new RequestCulture("en-UK"),

                    //formatting dates, numbers
                    SupportedCultures = supportedCultures,

                    //UI string that we have localized in resource file
                    SupportedUICultures = supportedCultures
            });

            #endregion

            app.UseRouting();

            //cors
            app.UseCors();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
