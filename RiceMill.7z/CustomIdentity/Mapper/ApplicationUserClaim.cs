﻿using Microsoft.AspNetCore.Identity;
using System;

namespace CustomIdentity
{
    public class ApplicationUserClaim : IdentityUserClaim<Guid>
    {
    }
}
